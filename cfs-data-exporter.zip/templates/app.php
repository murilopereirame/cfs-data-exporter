<div id="cfs-exporter-entry">
  <h2><?php esc_html_e('Loading', 'cfs-exporter-entry'); ?>...</h2>
</div>